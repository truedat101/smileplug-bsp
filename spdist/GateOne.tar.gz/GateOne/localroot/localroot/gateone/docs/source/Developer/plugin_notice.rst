The Notice Plugin
=================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: notice
    :members:
    :private-members:
