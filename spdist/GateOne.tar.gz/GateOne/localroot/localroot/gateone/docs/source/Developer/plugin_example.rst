.. _example-plugin:

The Example Plugin
==================

.. todo:: Write documentation on example.js.

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: example
    :members:
    :private-members:
