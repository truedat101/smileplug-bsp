The Help Plugin
===============

.. todo:: Write documentation on the Help plugin.