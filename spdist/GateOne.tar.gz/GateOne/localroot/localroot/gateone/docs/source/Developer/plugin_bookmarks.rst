The Bookmarks Plugin
====================

.. todo:: Write documentation on bookmarks.js.

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: bookmarks
    :members:
    :private-members:
